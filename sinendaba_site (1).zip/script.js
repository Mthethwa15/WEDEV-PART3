$(document).ready(function() {
    console.log("Sinendaba Charity Centre JS loaded.");

    // Helper: XSS Defense input sanitizer
    function sanitize(str) {
        return $('<div>').text(str).html();
    }

    // Highlight active nav tab based on URL
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    $('.nav-link').each(function() {
        if ($(this).attr('href') === currentPage) {
            $(this).addClass('bg-slate-700 text-emerald-400 font-bold');
        }
    });

    // Mobile menu toggle
    $('#mobile-menu-btn').on('click', function() {
        $('#mobile-menu').toggleClass('hidden');
    });

    // Accordion functionality
    $('.accordion-btn').on('click', function() {
        const content = $(this).next('.accordion-content');
        const icon = $(this).find('i');
        content.toggleClass('hidden');
        icon.toggleClass('rotate-180');
    });

    // Leaflet Map Setup on contact page
    if ($('#map').length > 0) {
        const tembisaCoords = [-25.9964, 28.2268];
        const map = L.map('map').setView(tembisaCoords, 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);

        L.marker(tembisaCoords).addTo(map)
            .bindPopup("<b>Sinendaba Charity Centre</b><br>Tembisa, Gauteng")
            .openPopup();
    }

    // Dynamic Items for index.html
    const items = [
        { title: "Kitchen Support Program", cat: "service", desc: "Serving warm meals to homeless adults & children in Tembisa daily.", img: "https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=400&auto=format&fit=crop", tag: "Daily Support" },
        { title: "Gauteng Food Packs Drive", cat: "service", desc: "Delivering essential nutrition packs to Soweto, Soshanguve & Ga-Rankuwa.", img: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=400&auto=format&fit=crop", tag: "Regional" },
        { title: "School Breakfast & Lunch Scheme", cat: "service", desc: "Providing nutritious food to local primary & preschool students.", img: "https://images.unsplash.com/photo-1542810634-71277d95dcbb?q=80&w=400&auto=format&fit=crop", tag: "Education" },
        { title: "Winter Warmth Clothing Drive", cat: "event", desc: "Collecting blankets & winter clothes for vulnerable families.", img: "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?q=80&w=400&auto=format&fit=crop", tag: "June 2026" },
        { title: "Emergency Family Meal Basket", cat: "product", desc: "Sponsor a month-long food pack for a household in need.", img: "https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=400&auto=format&fit=crop", tag: "R350 / Pack" }
    ];

    function renderGrid(filteredItems) {
        const grid = $('#dynamic-grid');
        grid.empty();
        if (filteredItems.length === 0) {
            grid.append('<div class="col-span-full text-center text-slate-500 py-8">No initiatives match your criteria.</div>');
            return;
        }
        filteredItems.forEach(item => {
            const card = `
                <div class="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-200 hover:shadow-md transition flex flex-col">
                    <img src="${sanitize(item.img)}" alt="${sanitize(item.title)}" class="h-44 w-full object-cover" loading="lazy">
                    <div class="p-5 flex-grow flex flex-col justify-between">
                        <div>
                            <span class="inline-block px-2.5 py-0.5 text-xs font-semibold rounded bg-slate-100 text-slate-700 mb-2">${sanitize(item.tag)}</span>
                            <h3 class="font-bold text-slate-800 text-lg">${sanitize(item.title)}</h3>
                            <p class="text-slate-600 text-sm mt-2">${sanitize(item.desc)}</p>
                        </div>
                    </div>
                </div>
            `;
            grid.append(card);
        });
    }

    if ($('#dynamic-grid').length > 0) {
        renderGrid(items);

        $('#search-input, #category-filter, #sort-filter').on('input change', function() {
            const query = $('#search-input').val().toLowerCase();
            const cat = $('#category-filter').val();
            const sort = $('#sort-filter').val();

            let result = items.filter(i => {
                const matchQuery = i.title.toLowerCase().includes(query) || i.desc.toLowerCase().includes(query);
                const matchCat = (cat === 'all') || (i.cat === cat);
                return matchQuery && matchCat;
            });

            if (sort === 'name-asc') {
                result.sort((a, b) => a.title.localeCompare(b.title));
            } else if (sort === 'name-desc') {
                result.sort((a, b) => b.title.localeCompare(a.title));
            }

            renderGrid(result);
        });
    }

    // Generic fallback submit handler for any OTHER forms.
    // The enquiry and contact forms have their own dedicated
    // validation + AJAX handlers, so they are excluded here.
    $('form:not(#enquiry-form):not(#contact-form)').on('submit', function(e) {
        e.preventDefault();
        showToast("Thank you! Your message has been sent securely.");
        this.reset();
    });

    function showToast(msg) {
        const toast = $(`<div class="toast-notification"><i class="fa-solid fa-shield-halved"></i> ${sanitize(msg)}</div>`);
        $('body').append(toast);
        setTimeout(() => toast.fadeOut(300, function() { $(this).remove(); }), 3500);
    }
});
